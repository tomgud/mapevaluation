#include "snow.h"
#include "tile.h"
#include "yield.h"
#include "feature.h"

Snow::Snow(int x, int  y) : 
	Tile(x, y, 0, 3, 1, false, false, 0.0,
		Yield(0, 0, 0), "Snow")
	
{
	this->features_on = new Feature[0];
	this->resources_on = new Resource[3];
	
	this->resources_on[0] = Resource(Resource::Iron);
	this->resources_on[1] = Resource(Resource::Oil);
	this->resources_on[2] = Resource(Resource::Uranium);
	
}

bool Snow::set_resource(Resource &res ) {
    this->res = res;
	return true;
}

bool Snow::set_feature(Feature &feat) {
	this->feat = feat;
	return true;
}

Resource& Snow::get_rand_resource(Resource::ResourceType type, int rnum) const {
    switch (type) {
        case Resource::Bonus:
            return *(new Resource(Resource::NO_RES_NAME));
        case Resource::Strategic:
            if (rnum % 3 == 0) {
                return *(new Resource(Resource::Iron));
            } else if (rnum % 3 == 1) {
                return *(new Resource(Resource::Oil));
            } else {
                return *(new Resource(Resource::Uranium));
            }
        case Resource::Luxury:
        case Resource::NO_RES_TYPE:
        default:
            return *(new Resource(Resource::NO_RES_NAME));

    }
}


Feature& Snow::get_rand_feature(int rnum) const {
    return *(new Feature(Feature::NO_FEAT));
}
