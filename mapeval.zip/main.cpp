#include <iostream>
#include <ctime>
#include "map.h"
#include "genome.h"
#include "civ5mapreader.h"
#include "civ5map.h"
#include "output_writer.h"
#include "player_manager.h"
#include "fitness.h"
#include "evolution.h"
using std::cout;
using std::endl;

#include "a_star.h"
/* To do a boost random numbers.
#include <boost/random.hpp> // Seems to work with only this header

#include <boost/random/mersenne_twister.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/exponential_distribution.hpp> <- this one doesn't work in linuxm int

    boost::mt19937 rng(seed);
    boost::variate_generator <boost::mt19937&, boost::normal_distribution<>> vg(rng, boost::normal_distribution<>(mean, std_dev));
    boost::variate_generator< boost::mt19937&, boost::exponential_distribution<> > rndm(rng, boost::exponential_distribution<>()) ;
    boost::random::uniform_int_distribution<> dist(1, 20);
    vg() is normal distribution double
    rndm() is exponential distribution double
    dist(rng) is uniform int distribution in the closed range [1,20]
*/
#include <boost/random.hpp>
int main() {
	// Civ5MapReader reader("../Civ5 Resources/testmap.Civ5Map");
	// reader.read();
	// Civ5Map civmap = reader.get_map(); 
	// civmap.to_map(map_from_file);
    // unsigned int seed =  (unsigned)time(0);
    Evolution e(15, 30);
    e.run();
    vector<Genome> gens = e.get_genomes();
    // Genome g(1345061103, 48, 4);


    PlayerManager pm(gens[0]);
    Map map_from_file(gens[0], pm);

    // cout << "<h2> Genome id: " << g.get_seed() << "</h2>";

    // PlayerManager pm(4);
    // string filename = "../Civ5 Resources/GreatPlainsSmall.Civ5Map";
    // cout << "<h2>" << filename << "</h2>";
    // Civ5MapReader reader(filename);
    // reader.read();
    // Civ5Map civmap = reader.get_map();
    // Map map_from_file;
    // civmap.to_map(map_from_file);
    Fitness::assign_resources(map_from_file, pm, false);
    cout << "Fitness all players: " << Fitness::starting_positions(map_from_file, pm) << "<br/>";
    cout << "Fitness continent: " << Fitness::players_in_a_continent(map_from_file, pm) << "<br/>";
    cout << "Fitness strategic resources: " << Fitness::strategic_resource(map_from_file, pm) << "<br/>";
    cout << "Fitness unique resources: " << Fitness::unique_resources(map_from_file, pm) << "<br/>";
    cout << "Fitness throughput per user: " << Fitness::throughput_per_player(map_from_file, pm) << "<br/>";

    OutputWriter::print_html(map_from_file);
}
