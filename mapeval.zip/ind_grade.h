#ifndef __ind_grade_h__
#define __ind_grade_h__

class IndGrade {
private:
	int id, selected;
	double fitness[5];
public:
	IndGrade(int id, double fit1, double fit2, double fit3, double fit4, double fit5) : id(id), selected(0) {
		this->fitness[0] = fit1;
		this->fitness[1] = fit2;
		this->fitness[2] = fit3;
		this->fitness[3] = fit4;
		this->fitness[4] = fit5;
	};
	void set_selected(int id) { this->selected = (id >= 0 && id < 5) ? id : this->selected; }
	void set_fit(const int& id, double f) { this->fitness[id] = f; }
	int get_id() const { return this->id; }
	int get_selected() const { return this->selected; }
	double get_fit(const int& id) const { return this->fitness[id]; }	
};

#endif

#ifndef __ind_grade_comp_h__
#define __ind_grade_comp_h__

class IndGradeComp {
    public:
        IndGradeComp(const bool& rev=false) : reverse(rev) {};
        bool operator() (const IndGrade *lhs, const IndGrade *rhs) const
        {
        	return lhs->get_fit(lhs->get_selected()) > rhs->get_fit(rhs->get_selected());
		}
    private:
        bool reverse;
};

#endif