#include "grassland.h"

Grassland::Grassland(int x, int  y) : 
	Tile(x, y, 2, 11, 1, false, false, 0.0,
		Yield(2, 0, 0), "Grassland")
{
	this->features_on = new Feature[2];
	this->resources_on = new Resource[11];
	
	// Setting up available features
	this->features_on[0] = Feature(Feature::Marsh);
	this->features_on[1] = Feature(Feature::Forest);
	
	// Setting up available resources
	this->resources_on[0] = Resource(Resource::Iron);
	this->resources_on[1] = Resource(Resource::Horses);
	this->resources_on[2] = Resource(Resource::Coal);
	this->resources_on[3] = Resource(Resource::Uranium);
	this->resources_on[4] = Resource(Resource::Sheep);
	this->resources_on[5] = Resource(Resource::Gold);
	this->resources_on[6] = Resource(Resource::Cattle);
	this->resources_on[7] = Resource(Resource::Gems);
	this->resources_on[8] = Resource(Resource::Marble);
	this->resources_on[9] = Resource(Resource::Cotton);
	this->resources_on[10] = Resource(Resource::Wine);
}

bool Grassland::set_resource(Resource &res ) {
    this->res = res;
	return false;
}

bool Grassland::set_feature(Feature &feat) {
	this->feat = feat;
	return true;
}

Resource& Grassland::get_rand_resource(Resource::ResourceType type, int rnum) const {
    switch (type) {
        case Resource::Bonus:
            return *(new Resource(Resource::Sheep));
        case Resource::Strategic:
            if (rnum % 4 == 0) {
                return *(new Resource(Resource::Iron));
            } else if (rnum % 4 == 1) {
                return *(new Resource(Resource::Horses));
            } else if (rnum % 4 == 2) {
                return *(new Resource(Resource::Coal)); 
            } else { 
                return *(new Resource(Resource::Uranium));
            }
        case Resource::Luxury:
            if (rnum % 6 == 0) {
                return *(new Resource(Resource::Gold));
            } else if (rnum % 6 == 1) {
                return *(new Resource(Resource::Cattle));
            } else if (rnum % 6 == 2) {
                return *(new Resource(Resource::Gems));
            } else if (rnum % 6 == 3) {
                return *(new Resource(Resource::Marble));
            } else if (rnum % 6 == 4) {
                return *(new Resource(Resource::Cotton));
            } else {
                return *(new Resource(Resource::Wine));
            }
        case Resource::NO_RES_TYPE:
        default:
            return *(new Resource(Resource::NO_RES_NAME));
    }
}

Feature& Grassland::get_rand_feature(int rnum) const {
    if (rnum % 2 == 0) {
        return *(new Feature(Feature::Marsh));
    } else { 
        return *(new Feature(Feature::Forest));
    }
}
