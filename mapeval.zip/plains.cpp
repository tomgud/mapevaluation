#include "plains.h"
#include "tile.h"
#include "yield.h"
#include "feature.h"

Plains::Plains(int x, int  y) : 
	Tile(x, y, 2, 14, 1,  false, false, 0.0,
		Yield(1, 1, 0), "Plains")
{
	this->features_on = new Feature[2];
	this->resources_on = new Resource[14];
	
	// Setting up available features
	this->features_on = new Feature(Feature::Jungle);
	this->features_on = new Feature(Feature::Forest);
	
	// Setting up available resources
	this->resources_on[0] = Resource(Resource::Iron);
	this->resources_on[1] = Resource(Resource::Horses);
	this->resources_on[2] = Resource(Resource::Aluminum);
	this->resources_on[3] = Resource(Resource::Uranium);
	this->resources_on[4] = Resource(Resource::Sheep);
	this->resources_on[5] = Resource(Resource::Gold);
	this->resources_on[6] = Resource(Resource::Coal);
	this->resources_on[7] = Resource(Resource::Gems);
	this->resources_on[8] = Resource(Resource::Marble);
	this->resources_on[9] = Resource(Resource::Cotton);
	this->resources_on[10] = Resource(Resource::Incense);
	this->resources_on[11] = Resource(Resource::Ivory);
	this->resources_on[12] = Resource(Resource::Wine);
	this->resources_on[13] = Resource(Resource::Wheat);
}

bool Plains::set_resource(Resource &res ) {
    this->res = res;
	return true;
}

bool Plains::set_feature(Feature &feat) {
	this->feat = feat;
	return true;
}
Resource& Plains::get_rand_resource(Resource::ResourceType type, int rnum) const {
    switch (type) {
        case Resource::Bonus:
            return *(new Resource(Resource::Sheep));
        case Resource::Strategic:
            if (rnum % 5 == 0) {
                return *(new Resource(Resource::Iron));
            } else if (rnum % 5 == 1) {
                return *(new Resource(Resource::Horses));
            } else if (rnum % 5 == 2) {
                return *(new Resource(Resource::Aluminum));
            } else if (rnum % 5 == 3) {
                return *(new Resource(Resource::Uranium));
            } else {
                return *(new Resource(Resource::Coal));
            }
        case Resource::Luxury:
            if (rnum % 8 == 0) {
                return *(new Resource(Resource::Gold));
            } else if (rnum % 8 == 1) { 
                return *(new Resource(Resource::Gems));
            } else if (rnum % 8 == 2) {
                return *(new Resource(Resource::Marble));
            } else if (rnum % 8 == 3) {
                return *(new Resource(Resource::Cotton));
            } else if (rnum % 8 == 4) {
                return *(new Resource(Resource::Incense));
            } else if (rnum % 8 == 5) {
                return *(new Resource(Resource::Ivory));
            } else if (rnum % 8 == 6) {
                return *(new Resource(Resource::Wine));
            } else {
                return *(new Resource(Resource::Wheat));
            }
        case Resource::NO_RES_TYPE:
        default:
            return *(new Resource(Resource::NO_RES_NAME));

    }
}
Feature& Plains::get_rand_feature(int rnum) const {
    if (rnum % 2 == 0 ) {
        return *(new Feature(Feature::Jungle));
    } else {
        return *(new Feature(Feature::Forest));
    }
}
