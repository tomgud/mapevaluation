#include "player_manager.h"
#include "player.h"
#include "genome.h"
#include "coords.h"
#include "map.h"
#include <vector>

#include <iostream>

PlayerManager::PlayerManager() : no_of_players(0), players(0)  {

}

PlayerManager::PlayerManager(int no_players) : no_of_players(no_players), 
    players(0)
{

    if (no_players == 2) {
        Player* p1 = new Player(0, 0, (Map::_DIMX/2), (Map::_DIMY/4));
        Player* p2 = new Player(1, 1, (Map::_DIMX/2), 3*(Map::_DIMY/4));
        this->players.push_back(p1);
        this->players.push_back(p2);
    } else if (no_players == 4) {
        Player* p1 = new Player(0, 0, (Map::_DIMX/4), (Map::_DIMY/4));
        Player* p2 = new Player(1, 0, (Map::_DIMX/4), 3*(Map::_DIMY/4));
        Player* p3 = new Player(2, 1, 3*(Map::_DIMX/4), (Map::_DIMY/4));	
        Player* p4 = new Player(3, 1, 3*(Map::_DIMX/4), 3*(Map::_DIMY/4));
        this->players.push_back(p1);
        this->players.push_back(p2);
        this->players.push_back(p3);
        this->players.push_back(p4);
   }
}

PlayerManager::PlayerManager(const Genome& g) :
    no_of_players(0), players(0)
{
    vector<CoOrd> p_c = g.get_player_starts();
    if (p_c.size() == 2) 
    {
        this->no_of_players = 2;
        this->players.push_back(new Player(0,0,
                    p_c[0].get_x(), p_c[0].get_y()));
        this->players.push_back(new Player(1,1,
                    p_c[1].get_x(), p_c[1].get_y()));
    }
    else if (p_c.size() == 4) 
    {
        this->no_of_players = 4;
        this->players.push_back(new Player(0,0,
                    p_c[0].get_x(), p_c[0].get_y()));
        this->players.push_back(new Player(1,0,
                    p_c[1].get_x(), p_c[1].get_y()));
        this->players.push_back(new Player(2,1,
                    p_c[2].get_x(), p_c[2].get_y()));
        this->players.push_back(new Player(3,1,
                    p_c[3].get_x(), p_c[3].get_y()));

    }
    else
    {
        //errorz
    }
}

vector<Player*> PlayerManager::get_players() {
    return this->players;
}

vector<Player*> PlayerManager::get_teammembers(int teamid) 
{
    vector<Player*> val;
    for (unsigned int i = 0; i < this->players.size(); ++i) 
    {
        if (players[i]->get_team() == teamid)
            val.push_back(players[i]);
    }
    return val;
}

Player* PlayerManager::get_player(int id) {
    if (id >= 0 && id < this->no_of_players) {
        return this->players[id];
    } else {
        return NULL;
    }
}

void PlayerManager::set_coord(int id, const CoOrd& c) {
    if (id >= 0 && id < this->no_of_players) {
        this->players[id]->set_start(c);
    }
}
