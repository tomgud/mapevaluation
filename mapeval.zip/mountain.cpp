#include "mountain.h"
#include "tile.h"
#include "yield.h"
#include "feature.h"

Mountain::Mountain(int x, int  y) : 
	Tile(x, y, 0, 0, 1, true, false, 0.0,
		Yield(0, 0, 0),  "Mountain")
{
	this->features_on = new Feature[0];
	this->resources_on = new Resource[0];
}

bool Mountain::set_resource(Resource &res ) {
	return false;
}

bool Mountain::set_feature(Feature &feat) {
	return false;
}

Resource& Mountain::get_rand_resource(Resource::ResourceType type, int rnum) const {
    return *(new Resource(Resource::NO_RES_NAME));
}

Feature& Mountain::get_rand_feature(int rnum) const {
    return *(new Feature(Feature::NO_FEAT));
}

