#include "tundra.h"
#include "tile.h"
#include "yield.h"
#include "feature.h"

Tundra::Tundra(int x, int  y) : 
	Tile(x, y, 1, 10, 1, false, false, 0.0, 
		Yield(1, 0, 0), "Tundra")
		
{
	this->features_on = new Feature[1];
	this->resources_on = new Resource[10];
	
	// Setting up available features
	this->features_on = new Feature(Feature::Forest);
	
	// Setting up available resources
	this->resources_on[0] = Resource(Resource::Iron);
	this->resources_on[1] = Resource(Resource::Oil);
	this->resources_on[2] = Resource(Resource::Aluminum);
	this->resources_on[3] = Resource(Resource::Uranium);
	this->resources_on[4] = Resource(Resource::Horses);
	this->resources_on[5] = Resource(Resource::Deer);
	this->resources_on[6] = Resource(Resource::Silver);
	this->resources_on[7] = Resource(Resource::Gems);
	this->resources_on[8] = Resource(Resource::Marble);
	this->resources_on[9] = Resource(Resource::Furs);
	
}

bool Tundra::set_resource(Resource &res ) {
    this->res = res;
	return false;
}

bool Tundra::set_feature(Feature &feat) {
	this->feat = feat;
	return true;
}

Resource& Tundra::get_rand_resource(Resource::ResourceType type, int rnum) const {
    switch (type) {
        case Resource::Bonus:
            return *(new Resource(Resource::Deer));
        case Resource::Strategic:
            if (rnum % 5 == 0) {
                return *(new Resource(Resource::Iron)); 
            } else if (rnum % 5 == 1) {
                return *(new Resource(Resource::Oil));
            } else if (rnum % 5 == 2) {
                return *(new Resource(Resource::Aluminum));
            } else if (rnum % 5 == 3) {
                return *(new Resource(Resource::Uranium));
            } else {
                return *(new Resource(Resource::Horses));
            }
        case Resource::Luxury:
            if (rnum % 4 == 0) {
                return *(new Resource(Resource::Silver));
            } else if (rnum % 4 == 1) {
                return *(new Resource(Resource::Gems));
            } else if (rnum % 4 == 2) {
                return *(new Resource(Resource::Marble));
            } else {
                return *(new Resource(Resource::Furs));
            }
        case Resource::NO_RES_TYPE:
        default:
            return *(new Resource(Resource::NO_RES_NAME));

    }
}


Feature& Tundra::get_rand_feature(int rnum) const {
    return *(new Feature(Feature::Forest));
}
