#include "evolution.h"
#include "genome.h"
#include "map.h"
#include "player_manager.h"
#include "mtrand.h"
#include "ind_grade.h"
#include "fitness.h"
#include <vector>
#include <queue>
#include <ctime>
using std::priority_queue;

#include <iostream>
using std::cout;
using std::endl;

Evolution::Evolution(int iters, int sz, double min_ch, int genome_sz, int no_of_p) : 
iters(iters), size(sz), genome_size(genome_sz), no_of_players(no_of_p),
min_change(min_ch), all_req_min_chg(true), gen_pop(0)
{
	unsigned int seed((unsigned)time(0));
	Genome cur_gen;
	for (int indiv(0); indiv < this->size; ++indiv) {
		cur_gen = Genome(seed+indiv, genome_sz, no_of_players);
		gen_pop.push_back(cur_gen);
	}
}

void Evolution::run() 
{
	// Just for fun, time outputs.
	char buffer[100];
	time_t rawtime;
	time ( &rawtime );

	double c_f1, c_f2, c_f3, c_f4, c_f5;
	IndGrade* c_ig;
	Map* c_map;
	PlayerManager* c_pm;
	priority_queue<IndGrade*, vector<IndGrade*>, IndGradeComp> indiv_one;
	priority_queue<IndGrade*, vector<IndGrade*>, IndGradeComp> indiv_two;
	for (int i = 0; i < iters; ++i) {
		for (int j = 0; j < this->size; ++j) { 
			c_pm = new PlayerManager(this->gen_pop[j]);
			c_map = new Map(this->gen_pop[j], *c_pm);
			Fitness::assign_resources(*c_map, *c_pm, false);
			c_f1 = Fitness::players_in_a_continent(*c_map, *c_pm);
			c_f2 = Fitness::starting_positions(*c_map, *c_pm);
			c_f3 = Fitness::strategic_resource(*c_map, *c_pm);
			c_f4 = Fitness::unique_resources(*c_map, *c_pm);
			c_f5 = Fitness::throughput_per_player(*c_map, *c_pm);
			c_ig = new IndGrade(this->gen_pop[j].get_seed(), c_f1, c_f2, c_f3, c_f4, c_f5);
			delete c_map;
			c_ig->set_selected(0);
			indiv_one.push(c_ig);
		}
		// First fitness function
		for (unsigned int k = 0; k < indiv_one.size(); ++k) {
			if (k < (3*indiv_one.size())/10) {
				indiv_one.pop();
			} else {
				c_ig = indiv_one.top();
				c_ig->set_selected(1);
				indiv_two.push(c_ig);
				indiv_one.pop();
			}
		}

		// Second fitness function
		for (unsigned int k = 0; k < indiv_two.size(); ++k) {
			if (k < (2*indiv_two.size())/7) {
				indiv_two.pop();
			} else {
				c_ig = indiv_two.top();
				c_ig->set_selected(2);
				indiv_one.push(c_ig);
				indiv_two.pop();
			}
		}

		// Third fitness function
		for (unsigned int k = 0; k < indiv_one.size(); ++k) {
			if (k < (indiv_one.size())/6) {
				indiv_one.pop();
			} else {
				c_ig = indiv_one.top();
				c_ig->set_selected(3);
				indiv_two.push(c_ig);
				indiv_one.pop();
			}
		}

		// Fourth fitness function
		for (unsigned int k = 0; k < indiv_two.size(); ++k) {
			if (k < (indiv_two.size())/5) {
				indiv_two.pop();
			} else {
				c_ig = indiv_two.top();
				c_ig->set_selected(4);
				indiv_one.push(c_ig);
				indiv_two.pop();
			}
		}

		vector<Genome> survivors;
		for (unsigned k = 0; k < indiv_one.size(); ++k) {
			c_ig = indiv_one.top();
			indiv_one.pop();
			for (int j = 0; j < this->size; ++j) {
				if (this->gen_pop[j].get_seed() == c_ig->get_id()) {
					survivors.push_back(this->gen_pop[j]);
					break;
				}
			}
		}

		// Creating offsprings.
		this->gen_pop.clear();
		this->gen_pop.assign(survivors.begin(), survivors.end());
		for (int j = this->gen_pop.size(); j < this->size; ++j) {
			Genome baby_cakes(survivors[i % survivors.size()]);
			baby_cakes.modify();
			this->gen_pop.push_back(baby_cakes);
		}
	}
}
