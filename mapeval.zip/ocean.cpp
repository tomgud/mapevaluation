#include "ocean.h"
#include "tile.h"
#include "yield.h"
#include "feature.h"

Ocean::Ocean(int x, int  y) : 
	Tile(x, y, 1, 0, 1, false, true, 0.0,
		Yield(1, 0, 1), "Ocean")
{
	this->features_on = new Feature[1];
	this->resources_on = new Resource[0];
	
	// Setting up available features
	this->features_on[0] = Feature(Feature::Ice);
}

bool Ocean::set_resource(Resource &res ) {
    this->res = res;
	return false;
}

bool Ocean::set_feature(Feature &feat) {
	this->feat = feat;
	return true;
}

Resource& Ocean::get_rand_resource(Resource::ResourceType type, int rnum) const {
    return *(new Resource(Resource::NO_RES_NAME));
}

Feature& Ocean::get_rand_feature(int rnum) const {
    return *(new Feature(Feature::Ice));
}

