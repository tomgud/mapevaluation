#include "hill.h"

Hill::Hill(int x, int  y) : 
	Tile(x, y, 0, 1, 2, false, false, 0.0, 
		Yield(0, 0, 0), "Hill")
{
	this->features_on = new Feature[0];
	this->resources_on = new Resource[1];
	
	this->resources_on[0] = Resource(Resource::Sheep);
}

bool Hill::set_resource(Resource &res ) {
    this->res = res;
	return false;
}

bool Hill::set_feature(Feature &feat) {
	this->feat = feat;
	return true;
}

Resource& Hill::get_rand_resource(Resource::ResourceType type, int rnum) const {
    switch (type) {
        case Resource::Bonus:
            return *(new Resource(Resource::Sheep));
        case Resource::Strategic:
        case Resource::Luxury:
        case Resource::NO_RES_TYPE:
        default:
            return *(new Resource(Resource::NO_RES_NAME));

    }
}

Feature& Hill::get_rand_feature(int rnum) const {
    return *(new Feature(Feature::NO_FEAT));
}

